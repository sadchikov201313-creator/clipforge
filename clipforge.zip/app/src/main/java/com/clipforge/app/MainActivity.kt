package com.clipforge.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.effect.Presentation
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.*
import androidx.media3.ui.PlayerView
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(modifier = Modifier.fillMaxSize()) { Editor() }
            }
        }
    }
}

@Composable
fun Editor() {
    val ctx = LocalContext.current
    var uri by remember { mutableStateOf<Uri?>(null) }
    var cw by remember { mutableStateOf("1080") }
    var ch by remember { mutableStateOf("1920") }
    var sx by remember { mutableFloatStateOf(1f) }
    var sy by remember { mutableFloatStateOf(1f) }
    var rot by remember { mutableFloatStateOf(0f) }
    var lock by remember { mutableStateOf(true) }
    var status by remember { mutableStateOf("") }

    val exo = remember { ExoPlayer.Builder(ctx).build().apply { repeatMode = Player.REPEAT_MODE_ALL } }
    DisposableEffect(Unit) { onDispose { exo.release() } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) {
            uri = u
            exo.setMediaItem(MediaItem.fromUri(u))
            exo.prepare()
            exo.playWhenReady = true
        }
    }

    val w = ((cw.toIntOrNull() ?: 1080).coerceIn(64, 4096) / 2) * 2
    val h = ((ch.toIntOrNull() ?: 1920).coerceIn(64, 4096) / 2) * 2

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxWidth().height(360.dp), contentAlignment = Alignment.Center) {
            val r = w.toFloat() / h
            val bw = if (maxWidth / r > maxHeight) maxHeight * r else maxWidth
            Box(modifier = Modifier.width(bw).height(bw / r).clipToBounds().background(Color.Black)) {
                AndroidView(
                    factory = { c ->
                        (LayoutInflater.from(c).inflate(R.layout.player_view, null) as PlayerView).also { it.player = exo }
                    },
                    modifier = Modifier.fillMaxSize().graphicsLayer(scaleX = sx, scaleY = sy, rotationZ = rot)
                )
            }
        }

        Button(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }, modifier = Modifier.fillMaxWidth()) {
            Text("Выбрать видео")
        }

        Text("Холст проекта")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("9:16" to (1080 to 1920), "16:9" to (1920 to 1080), "1:1" to (1080 to 1080), "4:5" to (1080 to 1350)).forEach { (n, s) ->
                OutlinedButton(onClick = { cw = s.first.toString(); ch = s.second.toString() }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text(n) }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = cw, onValueChange = { v -> cw = v.filter { c -> c.isDigit() } },
                modifier = Modifier.weight(1f), label = { Text("Ширина, px") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            OutlinedTextField(
                value = ch, onValueChange = { v -> ch = v.filter { c -> c.isDigit() } },
                modifier = Modifier.weight(1f), label = { Text("Высота, px") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
        }

        Text("Клип")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = lock, onCheckedChange = { lock = it })
            Text("Сохранять пропорции")
        }
        Text("Ширина клипа: ${(sx * 100).toInt()}%")
        Slider(value = sx, onValueChange = { sx = it; if (lock) sy = it }, valueRange = 0.2f..3f)
        Text("Высота клипа: ${(sy * 100).toInt()}%")
        Slider(value = sy, onValueChange = { sy = it; if (lock) sx = it }, valueRange = 0.2f..3f)
        Text("Поворот: ${rot.toInt()}°")
        Slider(value = rot, onValueChange = { rot = it }, valueRange = -180f..180f)

        Button(
            onClick = { uri?.let { exportVideo(ctx, it, w, h, sx, sy, rot) { s -> status = s } } },
            enabled = uri != null, modifier = Modifier.fillMaxWidth()
        ) { Text("Экспорт ${w}×${h}") }
        if (status.isNotEmpty()) Text(status)
    }
}

fun exportVideo(ctx: Context, src: Uri, w: Int, h: Int, sx: Float, sy: Float, rot: Float, onStatus: (String) -> Unit) {
    val f = File(ctx.cacheDir, "out_${System.currentTimeMillis()}.mp4")
    val effects = Effects(
        emptyList(),
        listOf<Effect>(
            ScaleAndRotateTransformation.Builder().setScale(sx, sy).setRotationDegrees(rot).build(),
            Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_SCALE_TO_FIT)
        )
    )
    val item = EditedMediaItem.Builder(MediaItem.fromUri(src)).setEffects(effects).build()
    val t = Transformer.Builder(ctx)
        .setVideoMimeType(MimeTypes.VIDEO_H264)
        .addListener(object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                try {
                    val v = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, f.name)
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ClipForge")
                    }
                    val dst = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
                    if (dst != null) {
                        ctx.contentResolver.openOutputStream(dst)?.use { o -> f.inputStream().use { it.copyTo(o) } }
                    }
                    onStatus("Готово: Movies/ClipForge/${f.name}")
                } catch (e: Exception) {
                    onStatus("Ошибка сохранения: ${e.message}")
                }
            }

            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                onStatus("Ошибка экспорта: ${exportException.message}")
            }
        })
        .build()
    onStatus("Экспорт ${w}×${h}…")
    t.start(item, f.absolutePath)
}
